.class public abstract Landroid/crosvm/ICrosvmAndroidDisplayService$Stub;
.super Landroid/os/Binder;
.source "ICrosvmAndroidDisplayService.java"

# interfaces
.implements Landroid/crosvm/ICrosvmAndroidDisplayService;


# direct methods
.method public static asInterface(Landroid/os/IBinder;)Landroid/crosvm/ICrosvmAndroidDisplayService;
    .locals 2

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    .line 57
    :cond_0
    const-string v0, "android.crosvm.ICrosvmAndroidDisplayService"

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 58
    instance-of v1, v0, Landroid/crosvm/ICrosvmAndroidDisplayService;

    if-eqz v1, :cond_1

    .line 59
    check-cast v0, Landroid/crosvm/ICrosvmAndroidDisplayService;

    return-object v0

    .line 61
    :cond_1
    new-instance v0, Landroid/crosvm/ICrosvmAndroidDisplayService$Stub$Proxy;

    invoke-direct {v0, p0}, Landroid/crosvm/ICrosvmAndroidDisplayService$Stub$Proxy;-><init>(Landroid/os/IBinder;)V

    return-object v0
.end method
