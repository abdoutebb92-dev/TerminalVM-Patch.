.class public interface abstract Landroid/crosvm/ICrosvmAndroidDisplayService;
.super Ljava/lang/Object;
.source "ICrosvmAndroidDisplayService.java"

# interfaces
.implements Landroid/os/IInterface;


# virtual methods
.method public abstract drawSavedFrameForSurface(Z)V
.end method

.method public abstract removeSurface(Z)V
.end method

.method public abstract saveFrameForSurface(Z)V
.end method

.method public abstract setCursorStream(Landroid/os/ParcelFileDescriptor;)V
.end method

.method public abstract setSurface(Landroid/view/Surface;Z)V
.end method
