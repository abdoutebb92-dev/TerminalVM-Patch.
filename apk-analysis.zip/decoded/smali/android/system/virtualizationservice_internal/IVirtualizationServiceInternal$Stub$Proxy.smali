.class Landroid/system/virtualizationservice_internal/IVirtualizationServiceInternal$Stub$Proxy;
.super Ljava/lang/Object;
.source "IVirtualizationServiceInternal.java"

# interfaces
.implements Landroid/system/virtualizationservice_internal/IVirtualizationServiceInternal;


# instance fields
.field private mRemote:Landroid/os/IBinder;


# direct methods
.method constructor <init>(Landroid/os/IBinder;)V
    .locals 0

    .line 392
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 393
    iput-object p1, p0, Landroid/system/virtualizationservice_internal/IVirtualizationServiceInternal$Stub$Proxy;->mRemote:Landroid/os/IBinder;

    return-void
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 0

    .line 397
    iget-object p0, p0, Landroid/system/virtualizationservice_internal/IVirtualizationServiceInternal$Stub$Proxy;->mRemote:Landroid/os/IBinder;

    return-object p0
.end method

.method public waitDisplayService()Landroid/os/IBinder;
    .locals 4

    .line 736
    invoke-virtual {p0}, Landroid/system/virtualizationservice_internal/IVirtualizationServiceInternal$Stub$Proxy;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    invoke-static {v0}, Landroid/os/Parcel;->obtain(Landroid/os/IBinder;)Landroid/os/Parcel;

    move-result-object v0

    .line 737
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    .line 740
    :try_start_0
    const-string v2, "android.system.virtualizationservice_internal.IVirtualizationServiceInternal"

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    .line 741
    iget-object p0, p0, Landroid/system/virtualizationservice_internal/IVirtualizationServiceInternal$Stub$Proxy;->mRemote:Landroid/os/IBinder;

    const/16 v2, 0x12

    const/4 v3, 0x0

    invoke-interface {p0, v2, v0, v1, v3}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    .line 742
    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V

    .line 743
    invoke-virtual {v1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 746
    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    .line 747
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    return-object p0

    :catchall_0
    move-exception p0

    .line 746
    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    .line 747
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    .line 748
    throw p0
.end method
