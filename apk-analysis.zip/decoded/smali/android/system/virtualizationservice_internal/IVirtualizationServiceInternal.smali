.class public interface abstract Landroid/system/virtualizationservice_internal/IVirtualizationServiceInternal;
.super Ljava/lang/Object;
.source "IVirtualizationServiceInternal.java"

# interfaces
.implements Landroid/os/IInterface;


# virtual methods
.method public abstract waitDisplayService()Landroid/os/IBinder;
.end method
