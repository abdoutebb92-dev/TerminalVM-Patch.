.class public abstract Landroidx/cardview/R$color;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static final cardview_dark_background:I = 0x7f05002b

.field public static final cardview_light_background:I = 0x7f05002c
