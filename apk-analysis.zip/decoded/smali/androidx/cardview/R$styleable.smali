.class public abstract Landroidx/cardview/R$styleable;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static final CardView:[I

.field public static final CardView_android_minHeight:I = 0x1

.field public static final CardView_android_minWidth:I = 0x0

.field public static final CardView_cardBackgroundColor:I = 0x2

.field public static final CardView_cardCornerRadius:I = 0x3

.field public static final CardView_cardElevation:I = 0x4

.field public static final CardView_cardMaxElevation:I = 0x5

.field public static final CardView_cardPreventCornerOverlap:I = 0x6

.field public static final CardView_cardUseCompatPadding:I = 0x7

.field public static final CardView_contentPadding:I = 0x8

.field public static final CardView_contentPaddingBottom:I = 0x9

.field public static final CardView_contentPaddingLeft:I = 0xa

.field public static final CardView_contentPaddingRight:I = 0xb

.field public static final CardView_contentPaddingTop:I = 0xc


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 0
    const/16 v0, 0xd

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Landroidx/cardview/R$styleable;->CardView:[I

    return-void

    :array_0
    .array-data 4
        0x101013f
        0x1010140
        0x7f0300a3
        0x7f0300a4
        0x7f0300a5
        0x7f0300a7
        0x7f0300a8
        0x7f0300a9
        0x7f03015f
        0x7f030160
        0x7f030162
        0x7f030163
        0x7f030165
    .end array-data
.end method
