.class Landroidx/concurrent/futures/AbstractResolvableFuture$Failure$1;
.super Ljava/lang/Throwable;
.source "AbstractResolvableFuture.java"


# direct methods
.method constructor <init>(Ljava/lang/String;)V
    .locals 0

    .line 222
    invoke-direct {p0, p1}, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public declared-synchronized fillInStackTrace()Ljava/lang/Throwable;
    .locals 0

    monitor-enter p0

    .line 225
    monitor-exit p0

    return-object p0
.end method
