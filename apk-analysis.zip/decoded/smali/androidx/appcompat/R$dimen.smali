.class public abstract Landroidx/appcompat/R$dimen;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static final abc_cascading_menus_min_smallest_width:I = 0x7f060016

.field public static final abc_config_prefDialogWidth:I = 0x7f060017

.field public static final abc_star_big:I = 0x7f06003b

.field public static final abc_star_medium:I = 0x7f06003c

.field public static final abc_star_small:I = 0x7f06003d
