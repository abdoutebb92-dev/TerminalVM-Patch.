.class public abstract Landroidx/appcompat/R$id;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static final action_bar:I = 0x7f080034

.field public static final action_bar_activity_content:I = 0x7f080035

.field public static final action_bar_container:I = 0x7f080036

.field public static final action_bar_subtitle:I = 0x7f080039

.field public static final action_bar_title:I = 0x7f08003a

.field public static final action_context_bar:I = 0x7f08003c

.field public static final action_menu_presenter:I = 0x7f080040

.field public static final action_mode_bar_stub:I = 0x7f080042

.field public static final action_mode_close_button:I = 0x7f080043

.field public static final alertTitle:I = 0x7f08004a

.field public static final buttonPanel:I = 0x7f080079

.field public static final content:I = 0x7f080096

.field public static final contentPanel:I = 0x7f080097

.field public static final custom:I = 0x7f0800a0

.field public static final customPanel:I = 0x7f0800a1

.field public static final decor_content_parent:I = 0x7f0800a6

.field public static final group_divider:I = 0x7f0800ea

.field public static final parentPanel:I = 0x7f080186

.field public static final scrollIndicatorDown:I = 0x7f0801ad

.field public static final scrollIndicatorUp:I = 0x7f0801ae

.field public static final scrollView:I = 0x7f0801af

.field public static final shortcut:I = 0x7f0801db

.field public static final spacer:I = 0x7f0801ea

.field public static final split_action_bar:I = 0x7f0801ed

.field public static final submenuarrow:I = 0x7f0801ff

.field public static final textSpacerNoButtons:I = 0x7f08021d

.field public static final textSpacerNoTitle:I = 0x7f08021e

.field public static final title:I = 0x7f08022b

.field public static final titleDividerNoCustom:I = 0x7f08022c

.field public static final title_template:I = 0x7f08022d

.field public static final topPanel:I = 0x7f080230
