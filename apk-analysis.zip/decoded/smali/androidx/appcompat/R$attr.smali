.class public abstract Landroidx/appcompat/R$attr;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static final actionBarPopupTheme:I = 0x7f030005

.field public static final actionBarSize:I = 0x7f030006

.field public static final actionBarStyle:I = 0x7f030008

.field public static final actionBarTheme:I = 0x7f03000c

.field public static final actionBarWidgetTheme:I = 0x7f03000d

.field public static final actionModePopupWindowStyle:I = 0x7f03001b

.field public static final actionModeStyle:I = 0x7f03001f

.field public static final actionOverflowButtonStyle:I = 0x7f030022

.field public static final actionOverflowMenuStyle:I = 0x7f030023

.field public static final alertDialogCenterButtons:I = 0x7f03002d

.field public static final alertDialogStyle:I = 0x7f03002e

.field public static final alertDialogTheme:I = 0x7f03002f

.field public static final autoCompleteTextViewStyle:I = 0x7f030044

.field public static final buttonStyle:I = 0x7f03009f

.field public static final checkboxStyle:I = 0x7f0300bb

.field public static final checkedTextViewStyle:I = 0x7f0300c6

.field public static final colorAccent:I = 0x7f0300fd

.field public static final colorButtonNormal:I = 0x7f0300ff

.field public static final colorControlActivated:I = 0x7f030103

.field public static final colorControlHighlight:I = 0x7f030104

.field public static final colorControlNormal:I = 0x7f030105

.field public static final colorSwitchThumbNormal:I = 0x7f030137

.field public static final dialogTheme:I = 0x7f03019d

.field public static final dropDownListViewStyle:I = 0x7f0301ba

.field public static final editTextStyle:I = 0x7f0301c0

.field public static final imageButtonStyle:I = 0x7f030275

.field public static final listMenuViewStyle:I = 0x7f030312

.field public static final listPopupWindowStyle:I = 0x7f030313

.field public static final panelMenuListTheme:I = 0x7f0303c6

.field public static final radioButtonStyle:I = 0x7f0303f2

.field public static final ratingBarStyle:I = 0x7f0303f4

.field public static final seekBarStyle:I = 0x7f030414

.field public static final spinnerStyle:I = 0x7f030442

.field public static final toolbarNavigationButtonStyle:I = 0x7f030523

.field public static final toolbarStyle:I = 0x7f030524
