.class interface abstract Landroidx/appcompat/app/AppCompatDelegateImpl$ActionBarMenuCallback;
.super Ljava/lang/Object;
.source "AppCompatDelegateImpl.java"


# virtual methods
.method public abstract onCreatePanelView(I)Landroid/view/View;
.end method

.method public abstract onPreparePanel(I)Z
.end method
